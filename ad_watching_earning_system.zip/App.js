import React, { useState } from "react";
import "./App.css";

function App() {
  const [balance, setBalance] = useState(0);

  const watchAd = () => {
    setBalance(balance + 5); // Earn 5 units per ad
  };

  return (
    <div className="App">
      <h1>Ad Watching Earning System</h1>
      <h2>Your Balance: ${balance}</h2>
      <button onClick={watchAd}>Watch Ad & Earn</button>
    </div>
  );
}

export default App;
